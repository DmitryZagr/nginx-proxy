#!/usr/bin/env python
"""
    ZTC Java monitoring package
    
    Copyright (c) 2009 Vladimir Rusinov <vladimir@greenmice.info>
    Copyright (c) 2009 Murano Software [http://muranosoft.com]
"""